@echo off
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  echo Run install.bat first.
  pause
  exit /b 1
)
start "" http://127.0.0.1:7860
.venv\Scripts\python.exe app.py
pause
